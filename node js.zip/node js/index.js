const express = require('express')
const { default: mongoose } = require('mongoose')
const app = express()
const path = require("path")
const port = 3000

const Router = require('./routs')

app.set('view engine', 'ejs')

app.use(express.static(path.join(__dirname, './views')))

app.use("/", Router);

mongoose.set("strictQuery", false);
mongoose.connect( 'mongodb+srv://elnurtolqinov1676:elnurtolqinov2006@cluster0.l08inxi.mongodb.net/?retryWrites=true&w=majority', {  useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => {
        app.listen(8000, () => {
            console.log('Successed DB connect')
            console.log('Server started on port http://localhost:8000');
        });
    })
    .catch((err) => {
        console.error(err);
    });

app.listen(port, () => {
    console.log(`Example app listening on port http://127.0.0.1:${port}`)
})