exports.index = async (req, res) => {
    res.render('index')
}
exports.fashion = async (req, res) => {
    res.render('fashion')
}
exports.electronic= async (req, res) => {
    res.render('electronic')
}
exports.jewellery= async (req, res) => {
    res.render('jewellery')
}