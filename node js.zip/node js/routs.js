const express = require ('express')
const routs = express.Router();

const indexController = require('./controller/indexController')

routs.get('/', indexController.index);

routs.get('/fashion', indexController.fashion);

routs.get('/electronic', indexController.electronic);

routs.get('/jewellery', indexController.jewellery)

module.exports = routs